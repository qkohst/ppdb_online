<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 10px 10px 10px 10px ">
    <div class="box">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form action="/calon_pesdik/daftar" method="POST" enctype="multipart/form-data">
            <h4><i class="nav-icon fas fa-address-book"></i> Form Pendaftaran Calon Peserta Didik Baru</h4>
            <hr>
            <?php echo e(csrf_field()); ?>

            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                    <!-- left column -->
                    <div class="col-md-6">
                        <!-- general form elements -->
                        <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Identitas Siswa</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input value="<?php echo e(old('nama_siswa')); ?>" name="nama_siswa" id="nama_siswa" type="text" class="form-control" placeholder="Nama Lengkap (Sesuai Akta Kelahiran)">
                            </div>
                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                <select name="jenis_kelamin" class="custom-select my-1 mr-sm-1 bg-light" id="jenis_kelamin"required>
                                    <option value="">-- Pilih Jenis Kelamin --</option>
                                    <option value="Laki-Laki">Laki-Laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tempat Lahir</label>
                                <input value="<?php echo e(old('tempat_lahir_siswa')); ?>"name="tempat_lahir_siswa" id="tempat_lahir_siswa" type="text" class="form-control" placeholder="Tempat Lahir">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_lahir_siswa">Tanggal Lahir</label>
                                <input value="<?php echo e(old('tanggal_lahir_siswa')); ?>" name="tanggal_lahir_siswa" type="date" class="form-control bg-light"
                                    id="tanggal_lahir_siswa" required>
                            </div>
                            <div class="form-group">
                                <label>NISN</label>
                                <input value="<?php echo e(old('nisn')); ?>" name="nisn" id="nisn" type="text" class="form-control" placeholder="Nomor Induk Siswa Nasional">
                            </div>
                            <div class="form-group">
                                <label>NIK</label>
                                <input value="<?php echo e(old('nik')); ?>" name="nik" id="nik" type="text" class="form-control" placeholder="Nomor Induk Kependudukan">
                            </div>
                            <div class="form-group">
                                <label for="agama_siswa">Agama</label>
                                <select name="agama_siswa" class="custom-select my-1 mr-sm-1 bg-light" id="agama_siswa"required>
                                    <option value="">-- Pilih Agama --</option>
                                    <option value="Islam">Islam</option>
                                    <option value="Kristen">Kristen</option>
                                    <option value="Hindu">Hindu</option>
                                    <option value="Budha">Budha</option>
                                    <option value="Konghucu">Konghucu</option>
                                </select>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                <label>Anak Ke</label>
                                <input value="<?php echo e(old('anak_ke')); ?>" name="anak_ke" id="anak_ke" type="text" class="form-control" placeholder="Anak Ke">
                                </div>
                                <div class="form-group col-md-6">
                                <label>Dari ..... Saudara</label>
                                <input value="<?php echo e(old('saudara')); ?>" name="saudara" id="saudara" type="text" class="form-control" placeholder="Saudara">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Nomor HP</label>
                                <input value="<?php echo e(old('no_hp')); ?>" name="no_hp" id="no_hp" type="text" class="form-control" placeholder="Nomor Induk Kependudukan">
                            </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- Form Element sizes -->
                        <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title">Sekolah Asal</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Nama Sekolah</label>
                                <input value="<?php echo e(old('sekolah_asal')); ?>" name="sekolah_asal" id="sekolah_asal" type="text" class="form-control" placeholder="Nama SD/MI Asal">
                            </div>
                            <div class="form-group">
                                <label>Alamat Sekolah</label>
                                <input value="<?php echo e(old('alamat_sekolah')); ?>" name="alamat_sekolah" id="alamat_sekolah" type="text" class="form-control" placeholder="Alamat Sekolah Asal">
                            </div>
                        </div>
                        <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">Alamat Siswa</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group">
                                <label>Alamat</label>
                                <input value="<?php echo e(old('alamat_siswa')); ?>" name="alamat_siswa" id="alamat_siswa" type="text" class="form-control" placeholder="Contoh : Jl. KH. Asyhary RT.001 RW.002">
                            </div>
                            <div class="form-group">
                                <label>Desa/Kelurahan</label>
                                <input value="<?php echo e(old('desa_siswa')); ?>" name="desa_siswa" id="desa_siswa" type="text" class="form-control" placeholder="Desa/Kelurahan">
                            </div>
                            <div class="form-group">
                                <label>Kecamatan</label>
                                <input value="<?php echo e(old('kecamatan_siswa')); ?>" name="kecamatan_siswa" id="kecamatan_siswa" type="text" class="form-control" placeholder="Kecamatan">
                            </div>
                            <div class="form-group">
                                <label>Kabupaten</label>
                                <input value="<?php echo e(old('kabupaten_siswa')); ?>" name="kabupaten_siswa" id="kabupaten_siswa" type="text" class="form-control" placeholder="Kabupaten">
                            </div>
                        </div>
                        </div>
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <div class="col-md-6">
                        <!-- general form elements disabled -->
                        <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">Identitas Ayah</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group">
                                <label>Nama Ayah</label>
                                <input value="<?php echo e(old('nama_ayah')); ?>" name="nama_ayah" id="nama_ayah" type="text" class="form-control" placeholder="Nama Ayah (Sesuai Akte Kelahiran)">
                            </div>
                            <div class="form-group">
                                <label>Tempat Lahir</label>
                                <input value="<?php echo e(old('tempat_lahir_ayah')); ?>" name="tempat_lahir_ayah" id="tempat_lahir_ayah" type="text" class="form-control" placeholder="Tempat Lahir Ayah">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_lahir_ayah">Tanggal Lahir</label>
                                <input value="<?php echo e(old('tanggal_lahir_ayah')); ?>" name="tanggal_lahir_ayah" type="date" class="form-control bg-light"
                                    id="tanggal_lahir_ayah" required>
                            </div>
                            <div class="form-group">
                                <label for="pendidikan_ayah">Pendidikan Terakhir</label>
                                <select name="pendidikan_ayah" class="custom-select my-1 mr-sm-1 bg-light" id="pendidikan_ayah"required>
                                    <option value="">-- Pilih Pendidikan Terakhir Ayah --</option>
                                    <option value="S-3">S-3</option>
                                    <option value="S-2">S-2</option>
                                    <option value="S-1">S-1</option>
                                    <option value="SLTA Sederajat">SLTA Sederajat</option>
                                    <option value="SLTP Sederajat">SLTP Sederajat</option>
                                    <option value="SD Sederajat">SD Sederajat</option>
                                    <option value="Tidak Sekolah">Tidak Sekolah</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="pekerjaan_ayah">Pekerjaan</label>
                                <select name="pekerjaan_ayah" class="custom-select my-1 mr-sm-1 bg-light" id="pekerjaan_ayah"required>
                                    <option value="">-- Pilih Pekerjaan Ayah --</option>
                                    <option value="Petani/Pekebun">Petani/Pekebun</option>
                                    <option value="Nelayan">Nelayan</option>
                                    <option value="Wiraswasta">Wiraswasta</option>
                                    <option value="Pedagang">Pedagang</option>
                                    <option value="Karyawan Swasta">Karyawan Swasta</option>
                                    <option value="Pegawai Negeri Sipil">Pegawai Negeri Sipil</option>
                                    <option value="Guru">Guru</option>
                                    <option value="Lainnya...">Lainnya...</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="status_ayah">Status Ayah</label>
                                <select name="status_ayah" class="custom-select my-1 mr-sm-1 bg-light" id="status_ayah"required>
                                    <option value="">-- Pilih Status Ayah --</option>
                                    <option value="Masih Hidup">Masih Hidup</option>
                                    <option value="Sudah Meninggal">Sudah Meninggal</option>
                                    <option value="Cerai">Cerai</option>
                                </select>
                            </div>
                        </div>
                        </div>
                        <!-- /.card -->
                        <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">Identitas Ibu</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group">
                                <label>Nama Ibu</label>
                                <input value="<?php echo e(old('nama_ibu')); ?>" name="nama_ibu" id="nama_ibu" type="text" class="form-control" placeholder="Nama Ibu (Sesuai Akte Kelahiran)">
                            </div>
                            <div class="form-group">
                                <label>Tempat Lahir</label>
                                <input value="<?php echo e(old('tempat_lahir_ibu')); ?>" name="tempat_lahir_ibu" id="tempat_lahir_ibu" type="text" class="form-control" placeholder="Tempat Lahir Ibu">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_lahir_ibu">Tanggal Lahir</label>
                                <input value="<?php echo e(old('tanggal_lahir_ibu')); ?>" name="tanggal_lahir_ibu" type="date" class="form-control bg-light"
                                    id="tanggal_lahir_ibu" required>
                            </div>
                            <div class="form-group">
                                <label for="pendidikan_ibu">Pendidikan Terakhir</label>
                                <select name="pendidikan_ibu" class="custom-select my-1 mr-sm-1 bg-light" id="pendidikan_ibu"required>
                                    <option value="">-- Pilih Pendidikan Terakhir Ibu --</option>
                                    <option value="S-3">S-3</option>
                                    <option value="S-2">S-2</option>
                                    <option value="S-1">S-1</option>
                                    <option value="SLTA Sederajat">SLTA Sederajat</option>
                                    <option value="SLTP Sederajat">SLTP Sederajat</option>
                                    <option value="SD Sederajat">SD Sederajat</option>
                                    <option value="Tidak Sekolah">Tidak Sekolah</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="pekerjaan_ibu">Pekerjaan</label>
                                <select name="pekerjaan_ibu" class="custom-select my-1 mr-sm-1 bg-light" id="pekerjaan_ibu"required>
                                    <option value="">-- Pilih Pekerjaan Ibu --</option>
                                    <option value="Mengurus Rumah Tangga">Mengurus Rumah Tangga</option>
                                    <option value="Petani/Pekebun">Petani/Pekebun</option>
                                    <option value="Nelayan">Nelayan</option>
                                    <option value="Wiraswasta">Wiraswasta</option>
                                    <option value="Pedagang">Pedagang</option>
                                    <option value="Karyawan Swasta">Karyawan Swasta</option>
                                    <option value="Pegawai Negeri Sipil">Pegawai Negeri Sipil</option>
                                    <option value="Guru">Guru</option>
                                    <option value="Lainnya...">Lainnya...</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="status_ibu">Status Ibu</label>
                                <select name="status_ibu" class="custom-select my-1 mr-sm-1 bg-light" id="status_ibu"required>
                                    <option value="">-- Pilih Status Ibu --</option>
                                    <option value="Masih Hidup">Masih Hidup</option>
                                    <option value="Sudah Meninggal">Sudah Meninggal</option>
                                    <option value="Cerai">Cerai</option>
                                </select>
                            </div>
                        </div>
                        </div>
                        <!-- /.card -->
                        <!-- general form elements disabled -->
                        <div class="card card-secondary">
                        <div class="card-header">
                            <h3 class="card-title">Upload Berkas .jpeg/.jpg</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleFormControlFile1">Akta Kelahiran</label>
                                <input name="file_akte" type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">Kartu Keluarga</label>
                                <input name="file_kk" type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">KTP Ayah</label>
                                <input name="file_ktp_ayah" type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">KTP Ibu</label>
                                <input name="file_ktp_ibu" type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">Ijazah</label>
                                <input name="file_ijazah" type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">SKHUN</label>
                                <input name="file_skhun" type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                        </div>
                        <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!--/.col (right) -->
                    </div>
                    <!-- /.row -->
                </div><!-- /.container-fluid -->
            </section>
            <hr>
            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-save"></i> DAFTAR</button>
            <a class="btn btn-danger btn-sm" href="/" role="button"><i class="fas fa-undo"></i> BATAL</a>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>